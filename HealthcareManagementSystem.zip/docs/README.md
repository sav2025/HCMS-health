# HealthcareManagementSystem

Detailed documentation for the project.
